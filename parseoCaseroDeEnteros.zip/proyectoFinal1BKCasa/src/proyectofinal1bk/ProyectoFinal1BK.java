package proyectofinal1bk;

import static proyectofinal1bk.Metodos.*;

public class ProyectoFinal1BK {

    public static void main(String[] args) {
        print("Ingrese un numero: ");
        String inputUser = leer();
        int length = inputUser.length();
        int[] arrayFinal = new int[length];
        int[] aux = new int[length];
        int sum = 0;
        String rojo = "\033[31m";

        if (!validarString(inputUser)) {
            print(rojo + "El valor ingresado debe ser un entero y no puede contener letras.");

        } else {

            if (!(length <= 11)) {
                print(rojo + "El valor puede tener un maximo de 11 caracteres.");

            } else {

                if (esNegativo(inputUser)) {

                    for (int i = 1; i <= length - 1; i++) {
                        int numericValue = Character.getNumericValue(inputUser.charAt(i));
                        aux[i] = numericValue;

                    }

                    int number = 0;

                    for (int i = length - 1; i >= 0; i--) {
                        arrayFinal[number] = aux[i];
                        number++;

                    }

                    for (int i = 0; i <= length - 1; i++) {
                        int multiplo = (int) (arrayFinal[i] * Math.pow(10, i));
                        sum = sum + multiplo;

                    }

                    sum = sum * (-1);
                    print("Numero valido");
                    print("Resultado "+sum);

                } else {

                    for (int i = 0; i <= length - 1; i++) {
                        int numero = Character.getNumericValue(inputUser.charAt(i));
                        aux[i] = numero;

                    }

                    int number = 0;

                    for (int i = length - 1; i >= 0; i--) {
                        arrayFinal[number] = aux[i];
                        number = number + 1;

                    }

                    for (int i = 0; i <= length - 1; i++) {
                        int multiplo = (int) (arrayFinal[i] * Math.pow(10, i));
                        sum = sum + multiplo;

                    }
                    print("Numero valido");
                    print("Resultado "+sum);

                }
            }
        }
    }
}
