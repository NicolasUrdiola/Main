package proyectofinal1bk;

import java.util.Scanner;

public class Metodos {

    public static void print(Object o) {
        System.out.println(o);
    }

    public static boolean validarString(String a) {
        return a.trim().matches("(-?)(?!0)([0-9]+)");

    }

    public static String leer() {
        Scanner tec = new Scanner(System.in);
        String inputUser = tec.nextLine();

        return inputUser;
    }
    
    public static boolean esNegativo(String a){
    return a.contains("-");
    }



}
